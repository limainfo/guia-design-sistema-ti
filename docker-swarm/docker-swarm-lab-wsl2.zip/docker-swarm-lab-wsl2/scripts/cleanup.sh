#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"

info "Removendo a stack, caso exista"
if docker ps --format '{{.Names}}' | grep -qx "$MANAGER_CONTAINER"; then
  manager stack rm "$STACK_NAME" >/dev/null 2>&1 || true
fi

info "Removendo nós, rede e volumes do laboratório"
compose down -v --remove-orphans
success "Laboratório removido por completo."
