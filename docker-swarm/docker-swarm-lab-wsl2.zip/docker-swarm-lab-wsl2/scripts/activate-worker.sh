#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"

info "Reativando swarm-worker1"
manager node update --availability active swarm-worker1
manager node ls
warn "A reativação permite novas tarefas, mas não força o rebalanceamento das existentes."
