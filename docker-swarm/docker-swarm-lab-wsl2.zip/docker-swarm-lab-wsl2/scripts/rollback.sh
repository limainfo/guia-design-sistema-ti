#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"

info "Solicitando rollback do serviço web"
manager service rollback "${STACK_NAME}_web"
manager service inspect --pretty "${STACK_NAME}_web"
