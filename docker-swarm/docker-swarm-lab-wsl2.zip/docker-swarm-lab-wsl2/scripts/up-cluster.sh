#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"

info "Iniciando os três Docker Engines do laboratório"
compose up -d

for node in "$MANAGER_CONTAINER" "$WORKER1_CONTAINER" "$WORKER2_CONTAINER"; do
  info "Aguardando Docker Engine em $node"
  wait_for_docker "$node"
done

MANAGER_IP="$(docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' "$MANAGER_CONTAINER")"
[[ -n "$MANAGER_IP" ]] || fail "Não foi possível identificar o IP do manager."

MANAGER_STATE="$(docker exec "$MANAGER_CONTAINER" docker info --format '{{.Swarm.LocalNodeState}}')"
if [[ "$MANAGER_STATE" != "active" ]]; then
  info "Inicializando o Swarm no manager ($MANAGER_IP)"
  docker exec "$MANAGER_CONTAINER" docker swarm init --advertise-addr "$MANAGER_IP"
else
  warn "O manager já pertence a um Swarm; mantendo o estado existente."
fi

WORKER_TOKEN="$(docker exec "$MANAGER_CONTAINER" docker swarm join-token -q worker)"

for node in "$WORKER1_CONTAINER" "$WORKER2_CONTAINER"; do
  state="$(docker exec "$node" docker info --format '{{.Swarm.LocalNodeState}}')"
  if [[ "$state" != "active" ]]; then
    info "Associando $node ao Swarm"
    docker exec "$node" docker swarm join --token "$WORKER_TOKEN" "$MANAGER_IP:2377"
  else
    warn "$node já pertence ao Swarm."
  fi
done

info "Nós registrados"
manager node ls
success "Cluster Swarm criado. Próximo passo: make deploy"
