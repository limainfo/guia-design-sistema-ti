#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"

info "Configs e secrets registrados no Swarm"
manager config ls
manager secret ls

TASK_ID="$(manager service ps -q "${STACK_NAME}_observer" --filter desired-state=running | head -n1)"
[[ -n "$TASK_ID" ]] || fail "Nenhuma tarefa observer em execução."

CONTAINER_ID="$(docker exec "$MANAGER_CONTAINER" docker ps --filter "label=com.docker.swarm.task.id=$TASK_ID" --format '{{.ID}}' | head -n1)"
[[ -n "$CONTAINER_ID" ]] || fail "Contêiner do observer não localizado no manager."

info "Conteúdo da config"
docker exec "$MANAGER_CONTAINER" docker exec "$CONTAINER_ID" cat /run/configs/app_environment

info "Metadados seguros do secret"
docker exec "$MANAGER_CONTAINER" docker exec "$CONTAINER_ID" sh -c \
  'printf "Bytes: "; wc -c < /run/secrets/demo_api_token; printf "SHA-256: "; sha256sum /run/secrets/demo_api_token | cut -d" " -f1'

warn "O valor integral do secret não foi impresso."
