#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"

info "Atualizando gradualmente o serviço web para traefik/whoami:v1.11.0"
manager service update \
  --image traefik/whoami:v1.11.0 \
  --update-parallelism 1 \
  --update-delay 3s \
  --update-order start-first \
  --update-failure-action rollback \
  "${STACK_NAME}_web"

manager service inspect --pretty "${STACK_NAME}_web"
success "Atualização solicitada. Use 'make status' para acompanhar as tarefas."
