#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"

REPLICAS="${1:-}"
[[ "$REPLICAS" =~ ^[0-9]+$ ]] || fail "Informe um número inteiro. Exemplo: ./scripts/scale.sh 9"

info "Alterando o serviço web para $REPLICAS réplica(s)"
manager service scale "${STACK_NAME}_web=${REPLICAS}"
wait_for_service "${STACK_NAME}_web" || true
manager service ls --filter "name=${STACK_NAME}_web"
manager service ps "${STACK_NAME}_web" --format 'table {{.Name}}\t{{.Node}}\t{{.CurrentState}}'
