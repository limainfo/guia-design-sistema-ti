#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"

info "Colocando swarm-worker1 em modo Drain"
manager node update --availability drain swarm-worker1
manager node ls
manager service ps "${STACK_NAME}_web" --format 'table {{.Name}}\t{{.Node}}\t{{.DesiredState}}\t{{.CurrentState}}'
