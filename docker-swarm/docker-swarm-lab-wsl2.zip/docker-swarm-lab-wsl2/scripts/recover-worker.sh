#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"

info "Iniciando novamente swarm-worker2"
docker start "$WORKER2_CONTAINER" >/dev/null
wait_for_docker "$WORKER2_CONTAINER"

info "Aguardando o nó reaparecer como Ready"
attempts=60
while (( attempts > 0 )); do
  status="$(manager node inspect swarm-worker2 --format '{{.Status.State}}' 2>/dev/null || true)"
  if [[ "$status" == "ready" ]]; then
    success "swarm-worker2 voltou ao estado Ready"
    break
  fi
  sleep 1
  ((attempts--))
done

manager node ls
