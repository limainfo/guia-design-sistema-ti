#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"

info "Testando routing mesh e distribuição entre réplicas"

for port in 8081 8082 8083; do
  printf '\nPorta %s:\n' "$port"
  for _ in $(seq 1 8); do
    response="$(curl -fsS --retry 3 --retry-connrefused --retry-delay 1 "http://localhost:${port}" 2>/dev/null || true)"
    hostname="$(printf '%s\n' "$response" | sed -n 's/^Hostname: //p' | head -n1)"
    if [[ -n "$hostname" ]]; then
      printf '  %s\n' "$hostname"
    else
      printf '  [sem resposta]\n'
    fi
  done
 done

success "O mesmo serviço foi acessado pelas portas dos três nós."
