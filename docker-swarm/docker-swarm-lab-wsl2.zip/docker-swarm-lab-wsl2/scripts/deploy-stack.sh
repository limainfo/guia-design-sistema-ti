#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"

wait_for_docker "$MANAGER_CONTAINER"

if [[ "$(docker exec "$MANAGER_CONTAINER" docker info --format '{{.Swarm.ControlAvailable}}')" != "true" ]]; then
  fail "O contêiner manager não está operando como manager Swarm. Execute: make up"
fi

info "Copiando manifesto, config e secret para o manager"
docker exec "$MANAGER_CONTAINER" rm -rf /lab-stack
docker exec "$MANAGER_CONTAINER" mkdir -p /lab-stack
docker cp "$ROOT_DIR/stack/." "$MANAGER_CONTAINER:/lab-stack/"

info "Implantando a stack $STACK_NAME"
docker exec -w /lab-stack "$MANAGER_CONTAINER" \
  docker stack deploy --prune --resolve-image always -c stack.yml "$STACK_NAME"

info "Aguardando as réplicas do serviço web"
wait_for_service "${STACK_NAME}_web" || true

manager stack services "$STACK_NAME"
success "Stack implantada. Acesse http://localhost:8081"
