#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"

info "Parando abruptamente o nó swarm-worker2"
docker stop "$WORKER2_CONTAINER" >/dev/null

info "Estado observado imediatamente após a interrupção"
manager node ls
manager service ps "${STACK_NAME}_web" --format 'table {{.Name}}\t{{.Node}}\t{{.DesiredState}}\t{{.CurrentState}}'

warn "A detecção de falha e o reescalonamento não são instantâneos. Execute 'make status' novamente para acompanhar."
