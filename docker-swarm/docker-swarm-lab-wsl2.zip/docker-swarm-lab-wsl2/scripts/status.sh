#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"

info "Contêineres que representam os nós"
compose ps

info "Nós do Swarm"
manager node ls

info "Serviços"
manager stack services "$STACK_NAME" || true

info "Distribuição das tarefas web"
manager service ps "${STACK_NAME}_web" --format 'table {{.Name}}\t{{.Image}}\t{{.Node}}\t{{.DesiredState}}\t{{.CurrentState}}' || true
