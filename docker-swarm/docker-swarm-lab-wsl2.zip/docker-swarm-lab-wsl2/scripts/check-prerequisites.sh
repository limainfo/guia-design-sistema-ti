#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"

info "Verificando pré-requisitos"

command -v docker >/dev/null 2>&1 || fail "Docker CLI não encontrado."
docker version >/dev/null 2>&1 || fail "Docker Engine não está acessível."
docker compose version >/dev/null 2>&1 || fail "Plugin Docker Compose não encontrado."
command -v curl >/dev/null 2>&1 || fail "curl não encontrado. Instale com: sudo apt install curl"

success "Docker Engine acessível"
docker version --format 'Cliente: {{.Client.Version}} | Servidor: {{.Server.Version}}'
docker compose version
success "Pré-requisitos atendidos"
