#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
COMPOSE_FILE="$ROOT_DIR/infrastructure/compose.cluster.yml"
MANAGER_CONTAINER="swarm-manager"
WORKER1_CONTAINER="swarm-worker1"
WORKER2_CONTAINER="swarm-worker2"
STACK_NAME="swarm-lab"

info() {
  printf '\n\033[1;34m[INFO]\033[0m %s\n' "$*"
}

success() {
  printf '\033[1;32m[OK]\033[0m %s\n' "$*"
}

warn() {
  printf '\033[1;33m[AVISO]\033[0m %s\n' "$*"
}

fail() {
  printf '\033[1;31m[ERRO]\033[0m %s\n' "$*" >&2
  exit 1
}

compose() {
  docker compose -f "$COMPOSE_FILE" "$@"
}

manager() {
  docker exec "$MANAGER_CONTAINER" docker "$@"
}

wait_for_docker() {
  local container="$1"
  local attempts=60

  while (( attempts > 0 )); do
    if docker exec "$container" docker info >/dev/null 2>&1; then
      return 0
    fi
    sleep 1
    ((attempts--))
  done

  fail "Docker Engine não ficou disponível em $container. Consulte: docker logs $container"
}

wait_for_service() {
  local service="$1"
  local attempts=90
  local desired running

  while (( attempts > 0 )); do
    desired="$(manager service inspect "$service" --format '{{.Spec.Mode.Replicated.Replicas}}' 2>/dev/null || true)"
    running="$(manager service ls --filter "name=$service" --format '{{.Replicas}}' 2>/dev/null | awk -F/ '{print $1}')"

    if [[ -n "$desired" && -n "$running" && "$desired" == "$running" ]]; then
      return 0
    fi

    sleep 1
    ((attempts--))
  done

  warn "O serviço ainda não atingiu o estado desejado. Verifique com: make status"
  return 1
}
